	<?php
	/**
	* Plugin Name: Multiple Files Upload
	* Description: You can add multiple images and crop them.
	* Version: 6.7.2
	* Author: Wp Admin
	**/

	
	if (!defined('ABSPATH')) {
	    exit;
	}


	require_once plugin_dir_path(__FILE__) . 'includes/file-upload-functions.php';

	// Hook to add menu
	add_action('admin_menu', 'mfu_add_admin_menu');

		function mfu_add_admin_menu() {
		    add_menu_page(
		        'Multiple Files Upload', 
		        'Custom Multiple Files Upload', 
		        'manage_options',
		        'mfu-settings', 
		        'mfu_settings_page', 
		        'dashicons-upload',
		        66
		    );
		}
	// Add settings link on the plugins page
	add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'mfu_add_settings_link');

	function mfu_add_settings_link($links) {
	    $settings_link = '<a href="admin.php?page=mfu-settings">Settings</a>';
	    array_unshift($links, $settings_link);
	    return $links;
	}
		function mfu_register_settings() {
	    register_setting('mfu_settings_group', 'mfu_min_images');
	    register_setting('mfu_settings_group', 'mfu_max_images');
		}


	add_action('admin_init', 'mfu_register_settings');

 

  function mfu_settings_page() {
	    ?>
	    <div class="wrap" style="text-align: center; padding-top: 81px; ext-transform: capitalize; line-height: 27px;">

	        <h1>Multiple Files Upload - Settings</h1>

	        <form method="post" action="options.php">
            <?php settings_fields('mfu_settings_group'); ?>
            <?php do_settings_sections('mfu_settings_group'); ?>
            <table class="form-table">
                <tr>
                   <th scope="row">Minimum Images</th>
                     <td>
                        <input type="number" name="mfu_min_images" value="<?php echo esc_attr(get_option('mfu_min_images', 4)); ?>"/>
                     </td> 
                </tr>
                <tr>
                <th scope="row">Maximum Images</th>
                   <td>
                      <input type="number" name="mfu_max_images" value="<?php echo esc_attr(get_option('mfu_max_images', 4)); ?>"/>
                   </td>
                </tr>
            </table>
            <?php submit_button();?>
        </form>

        <div class="plugin-admin-description" style="font-size:16px"><br><b> New Settings Coming Soon.........😊</b> </div>
	    </div>
	    <?php
	}
?>

