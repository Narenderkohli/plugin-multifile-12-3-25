
<?php 
   // single product image upload in order page code start here
          add_action('woocommerce_before_add_to_cart_button', 'custom_image_upload_field');
            function custom_image_upload_field() {
                ?>
                <div class="custom-upload-field">
                    
                    <input type="file" name="custom_image" id="custom_image"  hidden accept="image/*">
                    <br>
                    <a id="merged-image-link" href="#" target="_blank" style="display: none;">uploaded image </a>
                </div>

                <script>
                document.getElementById("custom_image").addEventListener("change", function(event) {
                    var reader = new FileReader();
                    reader.onload = function() {
                        var preview = document.getElementById("custom_image_preview");
                        preview.src = reader.result;
                        preview.style.display = "block";
                    };
                    reader.readAsDataURL(event.target.files[0]);
                });
                </script>
                <?php
            }


   
   //  cart image upload code 
      add_action('woocommerce_add_cart_item_data', 'save_custom_image_in_cart', 10, 3);
         function save_custom_image_in_cart($cart_item_data, $product_id) {
			 
            if (!empty($_FILES['custom_image']['name'])) {
                $upload = wp_upload_bits($_FILES['custom_image']['name'], null, file_get_contents($_FILES['custom_image']['tmp_name']));
                if (!$upload['error']) {
                    $cart_item_data['custom_image'] = esc_url($upload['url']);
                }
            }
            return $cart_item_data;
        }

		add_filter('woocommerce_get_item_data', 'display_custom_image_in_cart', 10, 2);
		function display_custom_image_in_cart($item_data, $cart_item) {
		if (isset($cart_item['custom_image'])) {
		$url = esc_url($cart_item['custom_image']);
		$item_data[] = array(
		'name'  => __('Uploaded Image', 'woocommerce'),
		'value' => '<span class="custom-image-url" data-url="' . esc_attr($url) . '">' . esc_html($url) . '</span>' // Store URL as data attribute
		);
		}
		return $item_data;
		}
 	
	 // checkout image upload code 
             add_filter('woocommerce_checkout_cart_item_quantity', 'display_custom_image_in_checkout', 10, 2);
				function display_custom_image_in_checkout($quantity, $cart_item) {
					if (isset($cart_item['custom_image'])) {
						$quantity .= '<p><strong>Uploaded Image:</strong><br><img src="' . esc_url($cart_item['custom_image']) . '" width="100"></p>';
					}
					return $quantity;
				}

        // Order page image upload code
		   add_action('woocommerce_checkout_create_order_line_item', 'save_custom_image_to_order', 10, 4);
			function save_custom_image_to_order($item, $cart_item_key, $values, $order) {
				if (isset($values['custom_image'])) {
					$item->add_meta_data('Uploaded Image', esc_url($values['custom_image']), true);
				}
			}
			
	   // admin image upload code
		  add_filter('woocommerce_order_item_name', 'display_custom_image_in_admin_order', 10, 2);
				function display_custom_image_in_admin_order($item_name, $item) {
					if ($custom_image = $item->get_meta('Uploaded Image')) {
						$item_name .= '<p><strong>Uploaded Image:</strong><br><img src="' . esc_url($custom_image) . '" width="100"></p>';
					}
					return $item_name;
				}
				
	// multi image upload display code file			
			add_action('woocommerce_before_add_to_cart_button', 'multi_image_upload_single_page');
			function multi_image_upload_single_page() {
            require_once plugin_dir_path(__FILE__) . 'files-upload.php';
			}



// Display name input field on product page
// add_action('woocommerce_before_add_to_cart_button', 'custom_name_input_field');

function custom_name_input_field() {
    echo '<p><label for="custom_name">Enter Your Name:</label></p>';
    echo '<input type="text" name="custom_name" id="custom_name" required>';
}


// Save the custom field value to cart item
// add_filter('woocommerce_add_cart_item_data', 'save_custom_name_to_cart', 10, 2);

function save_custom_name_to_cart($cart_item_data, $product_id) {
    if (!empty($_POST['custom_name'])) {
        $cart_item_data['custom_name'] = sanitize_text_field($_POST['custom_name']);
    }
    return $cart_item_data;
}


// Display the custom name in cart and checkout
 // add_filter('woocommerce_get_item_data', 'display_custom_name_in_cart', 10, 2);

function display_custom_name_in_cart($item_data, $cart_item) {
    if (!empty($cart_item['custom_name'])) {
        $item_data[] = array(
            'name' => 'Customer Name',
            'value' => esc_html($cart_item['custom_name'])
        );
    }
    return $item_data;
}



function custom_inline_script() {
    ?>
    <script>
    jQuery(document).ready(function () {
		
	setTimeout(function () {
		
    jQuery(".wc-block-components-product-details__uploaded-image").each(function () {
        var image_val = jQuery(this).find(".wc-block-components-product-details__value").text().trim();
        console.log(image_val);
         jQuery(".wc-block-components-product-details__value").hide();
                 if (image_val) { // Ensure there's a value before appending
            var anchorTag = jQuery('<a>', {
                href: image_val, 
                text: ' ' + image_val, 
                target: '_blank', 
                class: 'custom-anchor' 
            });

            jQuery(this).find(".wc-block-components-product-details__name").after(anchorTag);
        }
    });
	},2000);
});    
    </script>
    <?php
}
add_action('wp_footer', 'custom_inline_script');